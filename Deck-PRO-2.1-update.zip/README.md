# Deck PRO 2.1 technical test

Changes:
- Correct row count from deck width / board width / gap.
- Optimization always aims at 100%; no user-set utilization target.
- New-deck mode can create special connection-support positions and reports them.
- Consistent piece IDs across row plan and stock-board cutting plan.
- Kerf and available remainder are reported separately.
- Last-board width adjustment is shown.

Engineering status:
This remains a heuristic optimization prototype, not a structural engineering calculator. It does not guarantee the mathematical global optimum. Joist/support sizes, spans, fasteners, bearing and structural requirements must be validated independently.
